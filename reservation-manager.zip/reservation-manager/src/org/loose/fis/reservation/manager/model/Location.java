package org.loose.fis.reservation.manager.model;

public class Location {
}

package org.loose.fis.reservation.manager.services;

public class DummyService {
}
